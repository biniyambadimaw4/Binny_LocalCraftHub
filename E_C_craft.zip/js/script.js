// Local Craft Hub - JavaScript functions
// This file is ready for future enhancements

console.log('Local Craft Hub loaded successfully!');

// Cart quantity validation
function validateQuantity(input) {
    if (input.value < 1) {
        input.value = 1;
    }
    if (input.value > 10) {
        input.value = 10;
    }
}