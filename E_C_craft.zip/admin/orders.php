<?php
$page_title = "Manage Orders";
include '../includes/header.php';

// Check if user is admin/artisan
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'artisan') {
    header("Location: ../login.php");
    exit;
}

// Handle order status update
if (isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];
    
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$new_status, $order_id]);
    
    echo '<div class="alert alert-success">Order status updated successfully!</div>';
}

// Get all orders with customer information
$stmt = $pdo->query("
    SELECT o.*, u.name as customer_name, u.email as customer_email,
           os.full_name, os.phone, os.address, os.city
    FROM orders o 
    LEFT JOIN users u ON o.user_id = u.id 
    LEFT JOIN order_shipping os ON o.id = os.order_id 
    ORDER BY o.created_at DESC
");
$orders = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Manage Orders</h2>
    <span class="badge bg-primary"><?php echo count($orders); ?> orders</span>
</div>

<div class="card">
    <div class="card-body">
        <?php if ($orders): ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Contact</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($orders as $order): ?>
                        <tr>
                            <td>
                                <strong>#<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></strong>
                            </td>
                            <td>
                                <div>
                                    <strong><?php echo $order['full_name']; ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo $order['customer_email']; ?></small>
                                </div>
                            </td>
                            <td>
                                <small><?php echo $order['phone']; ?></small>
                                <br>
                                <small class="text-muted"><?php echo $order['city']; ?></small>
                            </td>
                            <td>$<?php echo number_format($order['total_amount'], 2); ?></td>
                            <td>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                    <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                                        <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                        <option value="completed" <?php echo $order['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                        <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                    </select>
                                    <input type="hidden" name="update_status" value="1">
                                </form>
                            </td>
                            <td><?php echo date('M j, Y', strtotime($order['created_at'])); ?></td>
                            <td>
                                <a href="order_details.php?order_id=<?php echo $order['id']; ?>" 
                                   class="btn btn-sm btn-outline-primary">View Details</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <h4>No orders yet</h4>
                <p class="text-muted">Orders will appear here when customers place them.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>