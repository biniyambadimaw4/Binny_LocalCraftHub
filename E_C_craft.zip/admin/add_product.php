<?php
$page_title = "Add Product";
include '../includes/header.php';

// Check if user is admin/artisan
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'artisan') {
    header("Location: ../login.php");
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = $_POST['price'];
    $category = $_POST['category'];
    $stock = $_POST['stock'];
    
    $errors = [];
    
    // Validation
    if (empty($name)) $errors[] = "Product name is required";
    if (empty($description)) $errors[] = "Description is required";
    if (empty($price) || $price <= 0) $errors[] = "Valid price is required";
    if (empty($category)) $errors[] = "Category is required";
    
    // Handle image upload
    $image_name = 'placeholder.jpg'; // Default image
    
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        $file_extension = strtolower(pathinfo($_FILES['product_image']['name'], PATHINFO_EXTENSION));
        
        // Check file type
        if (!in_array($file_extension, $allowed_extensions)) {
            $errors[] = "Only JPG, JPEG, PNG & GIF files are allowed.";
        }
        
        // Check file size (max 2MB)
        if ($_FILES['product_image']['size'] > 2097152) {
            $errors[] = "File size must be less than 2MB.";
        }
        
        if (empty($errors)) {
            // Generate unique filename
            $image_name = uniqid() . '_' . time() . '.' . $file_extension;
            $upload_path = '../images/products/' . $image_name;
            
            // Create products directory if it doesn't exist
            if (!is_dir('../images/products')) {
                mkdir('../images/products', 0777, true);
            }
            
            // Move uploaded file
            if (!move_uploaded_file($_FILES['product_image']['tmp_name'], $upload_path)) {
                $errors[] = "Failed to upload image.";
                $image_name = 'placeholder.jpg';
            }
        }
    }
    
    if (empty($errors)) {
        $stmt = $pdo->prepare("
            INSERT INTO products (name, description, price, category, image, stock, artisan_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        if ($stmt->execute([$name, $description, $price, $category, $image_name, $stock, $_SESSION['user_id']])) {
            echo '<div class="alert alert-success">Product added successfully!</div>';
            // Clear form
            $name = $description = $category = '';
            $price = $stock = '';
        } else {
            $errors[] = "Failed to add product. Please try again.";
        }
    }
    
    // Display errors
    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo '<div class="alert alert-danger">' . $error . '</div>';
        }
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h4>Add New Product</h4>
            </div>
            <div class="card-body">
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="name" class="form-label">Product Name *</label>
                        <input type="text" class="form-control" id="name" name="name" 
                               value="<?php echo $_POST['name'] ?? ''; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description *</label>
                        <textarea class="form-control" id="description" name="description" 
                                  rows="4" required><?php echo $_POST['description'] ?? ''; ?></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="price" class="form-label">Price ($) *</label>
                            <input type="number" class="form-control" id="price" name="price" 
                                   step="0.01" min="0.01" value="<?php echo $_POST['price'] ?? ''; ?>" required>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="stock" class="form-label">Stock Quantity *</label>
                            <input type="number" class="form-control" id="stock" name="stock" 
                                   min="1" value="<?php echo $_POST['stock'] ?? '1'; ?>" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="category" class="form-label">Category *</label>
                        <select class="form-select" id="category" name="category" required>
                            <option value="">Select Category</option>
                            <option value="pottery" <?php echo ($_POST['category'] ?? '') == 'pottery' ? 'selected' : ''; ?>>Pottery</option>
                            <option value="textiles" <?php echo ($_POST['category'] ?? '') == 'textiles' ? 'selected' : ''; ?>>Textiles</option>
                            <option value="woodwork" <?php echo ($_POST['category'] ?? '') == 'woodwork' ? 'selected' : ''; ?>>Woodwork</option>
                            <option value="jewelry" <?php echo ($_POST['category'] ?? '') == 'jewelry' ? 'selected' : ''; ?>>Jewelry</option>
                            <option value="painting" <?php echo ($_POST['category'] ?? '') == 'painting' ? 'selected' : ''; ?>>Painting</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="product_image" class="form-label">Product Image</label>
                        <input type="file" class="form-control" id="product_image" name="product_image" 
                               accept="image/jpeg, image/png, image/gif, image/jpg">
                        <div class="form-text">
                            Supported formats: JPG, JPEG, PNG, GIF. Max file size: 2MB.
                        </div>
                        
                        <!-- Image preview -->
                        <div class="mt-2" id="imagePreview" style="display: none;">
                            <img id="preview" src="#" alt="Image preview" style="max-width: 200px; max-height: 200px; border: 1px solid #ddd; border-radius: 5px;">
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary btn-lg">Add Product</button>
                        <a href="products.php" class="btn btn-outline-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Image preview functionality
document.getElementById('product_image').addEventListener('change', function(e) {
    const preview = document.getElementById('preview');
    const previewContainer = document.getElementById('imagePreview');
    
    if (this.files && this.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            preview.src = e.target.result;
            previewContainer.style.display = 'block';
        }
        
        reader.readAsDataURL(this.files[0]);
    } else {
        previewContainer.style.display = 'none';
    }
});
</script>

<?php include '../includes/footer.php'; ?>