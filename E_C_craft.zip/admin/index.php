<?php
$page_title = "Admin Dashboard";
include '../includes/header.php';

// Check if user is admin/artisan
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'artisan') {
    header("Location: ../login.php");
    exit;
}

// Get statistics
$products_count = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$orders_count = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$users_count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$revenue = $pdo->query("SELECT SUM(total_amount) FROM orders WHERE status = 'completed'")->fetchColumn();
?>

<div class="row">
    <div class="col-12">
        <h2>Admin Dashboard</h2>
        <p class="text-muted">Manage your craft business</p>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mt-4">
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo $products_count; ?></h4>
                        <p>Total Products</p>
                    </div>
                    <div class="align-self-center">
                        <span style="font-size: 2rem;">🏺</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-success">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo $orders_count; ?></h4>
                        <p>Total Orders</p>
                    </div>
                    <div class="align-self-center">
                        <span style="font-size: 2rem;">📦</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo $users_count; ?></h4>
                        <p>Total Users</p>
                    </div>
                    <div class="align-self-center">
                        <span style="font-size: 2rem;">👥</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-info">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4>$<?php echo number_format($revenue ?? 0, 2); ?></h4>
                        <p>Total Revenue</p>
                    </div>
                    <div class="align-self-center">
                        <span style="font-size: 2rem;">💰</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5>Quick Actions</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 text-center mb-3">
                        <a href="products.php" class="btn btn-outline-primary btn-lg w-100 py-3">
                            <div style="font-size: 2rem;">📋</div>
                            Manage Products
                        </a>
                    </div>
                    <div class="col-md-3 text-center mb-3">
                        <a href="orders.php" class="btn btn-outline-success btn-lg w-100 py-3">
                            <div style="font-size: 2rem;">🛒</div>
                            View Orders
                        </a>
                    </div>
                    <div class="col-md-3 text-center mb-3">
                        <a href="add_product.php" class="btn btn-outline-warning btn-lg w-100 py-3">
                            <div style="font-size: 2rem;">➕</div>
                            Add Product
                        </a>
                    </div>
                    <div class="col-md-3 text-center mb-3">
                        <a href="../index.php" class="btn btn-outline-info btn-lg w-100 py-3">
                            <div style="font-size: 2rem;">🏠</div>
                            View Site
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Orders -->
<div class="row mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5>Recent Orders</h5>
            </div>
            <div class="card-body">
                <?php
                $stmt = $pdo->query("
                    SELECT o.*, u.name as customer_name 
                    FROM orders o 
                    LEFT JOIN users u ON o.user_id = u.id 
                    ORDER BY o.created_at DESC 
                    LIMIT 5
                ");
                $recent_orders = $stmt->fetchAll();
                
                if ($recent_orders):
                ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($recent_orders as $order): ?>
                            <tr>
                                <td>#<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo $order['customer_name']; ?></td>
                                <td>$<?php echo number_format($order['total_amount'], 2); ?></td>
                                <td>
                                    <span class="badge bg-<?php 
                                        echo $order['status'] == 'completed' ? 'success' : 
                                             ($order['status'] == 'cancelled' ? 'danger' : 'warning'); 
                                    ?>">
                                        <?php echo ucfirst($order['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M j, Y', strtotime($order['created_at'])); ?></td>
                                <td>
                                    <a href="order_details.php?order_id=<?php echo $order['id']; ?>" 
                                       class="btn btn-sm btn-outline-primary">View</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                    <p class="text-center text-muted">No orders yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>